package com.fss.cms.sample.service;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fss.cms.sample.dao.SampleDao;
import com.fss.cms.sample.pojo.SampleForm;

import jdk.nashorn.internal.ir.annotations.Ignore;

@RunWith(SpringRunner.class)
public class SampleServiceTest {
	
	  
	@Mock
	private ValidationUtil util;

	@Mock
	private SampleDao sampleDao;

	@InjectMocks
	private SampleService sampleService;

	@Test
	public void testFetchProgramDetails() {
		SampleForm form = new SampleForm();
		form.setBinNumber("400001");
		form.setBinName("VisaDebitBin");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");

		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("400001");
		responseForm.setBinName("VisaDebitBin");
		responseForm.setProgramCode("VDP");
		responseForm.setProgramName("Visa Debit Program");

		Mockito.when(util.isNull(Mockito.anyString())).thenReturn(false);

		Mockito.when(sampleDao.fetchProgramDetails(Mockito.anyString())).thenReturn(form);
	  
	  
	  assertEquals(responseForm.getBinNumber(),sampleService.fetchProgramDetails(
	  form.getBinNumber()).getBinNumber());
	  
	  
	  }
	  
	@Test
	public void testFetchProgramDetailsNeg() {
		SampleForm form = new SampleForm();
		form.setBinNumber("400001");
		form.setBinName("VisaDebitBin");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");

		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("400002");
		responseForm.setBinName("VisaDebitBin");
		responseForm.setProgramCode("VDP");
		responseForm.setProgramName("Visa Debit Program");

		Mockito.when(util.isNull("")).thenReturn(true);

		Mockito.when(sampleDao.fetchProgramDetails(Mockito.anyString())).thenReturn(form);
	  
	  
	  assertNotEquals(responseForm.getBinNumber(),sampleService.fetchProgramDetails(
	  form.getBinNumber()).getBinNumber());
	  
	  
	  }
	
	
	//@Test(expected = NullPointerException.class) 
	@Ignore
	public void testFetchProgramDetailsNull() {
		SampleForm form = new SampleForm();
		form.setBinNumber("400001");
		form.setBinName("VisaDebitBin");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");

		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("400001");
		responseForm.setBinName("VisaDebitBin");
		responseForm.setProgramCode("VDP");
		responseForm.setProgramName("Visa Debit Program");

		Mockito.when(util.isNull("")).thenReturn(true);

		Mockito.when(sampleDao.fetchProgramDetails(Mockito.anyString())).thenReturn(form);
	  
	  
	  assertNotEquals(responseForm.getBinNumber(),sampleService.fetchProgramDetails(
	  form.getBinNumber()).getBinNumber());  
	  
	}
	@Test
	public void testSaveProgramDetails() {
		SampleForm form = new SampleForm();
		form.setBinNumber("400001");
		form.setBinName("VisaDebitBin");
		form.setProgramCode("VDP");
		form.setProgramName("Visa Debit Program");
		form.setResponseCode("0");
		SampleForm responseForm = new SampleForm();
		responseForm.setBinNumber("400001");
		responseForm.setBinName("VisaDebitBin");
		responseForm.setProgramCode("VDP");
		responseForm.setProgramName("Visa Debit Program");
		responseForm.setResponseCode("0");

		Mockito.when(sampleDao.saveBinDetails(Mockito.any())).thenReturn(true);
	  
	  assertEquals(responseForm.getResponseCode(),sampleService.saveProgramDetails(form).getResponseCode());  
	}
	
	 }