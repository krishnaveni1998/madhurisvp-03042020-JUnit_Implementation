package com.fss.cms.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fss.cms.sample.dao.SampleDao;
import com.fss.cms.sample.pojo.SampleForm;

@Service
public class SampleService {
	@Autowired
	SampleDao sampledao;
	@Autowired
	ValidationUtil util;
	public SampleForm  fetchProgramDetails(String binNo) {
		SampleForm form=new SampleForm();
		System.out.println("inside service");
		if(!util.isNull(binNo)) {
			//if(util.isNumeric(binNo)) {
				form = sampledao.fetchProgramDetails(binNo);
				if(form.getBinName() != null && form.getBinName()!= "") {
					form.setResponseCode("0");
					form.setResponseMessage("Details fetched successfully");
				}else {
					form.setResponseCode("99");
					form.setResponseMessage("No details present for the given input");
				}
				
			//}
		}else {
			form.setResponseCode("98");
			form.setResponseMessage("Input string cannot be empty");
		}
		return form;
	}
	public SampleForm saveProgramDetails(SampleForm form) {
		// TODO Auto-generated method stub
		boolean flag = sampledao.saveBinDetails(form);
		System.out.println("flagservice::"+flag);
		if(flag) {
			form.setResponseCode("0");
			form.setResponseMessage("Details Inserted Successfully");
		}else {
			form.setResponseCode("99");
			form.setResponseMessage("Insertion Failed");
		}
		return form;
	}
	public SampleForm updateProgramDetails(SampleForm form) {
		// TODO Auto-generated method stub
		boolean flag = sampledao.updateBinDetails(form);
		if(flag) {
			form.setResponseCode("0");
			form.setResponseMessage("Details updated successfully");
		}else {
			form.setResponseCode("99");
			form.setResponseMessage("Updation failed");
		}
		return form;
	}
	
	
}
