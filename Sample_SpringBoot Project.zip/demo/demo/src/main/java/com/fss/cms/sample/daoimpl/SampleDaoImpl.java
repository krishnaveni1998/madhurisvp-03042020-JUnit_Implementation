package com.fss.cms.sample.daoimpl;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import com.fss.cms.sample.dao.SampleDao;
import com.fss.cms.sample.pojo.SampleForm;

@Repository
public class SampleDaoImpl implements SampleDao {

	private DataSource ds;

	public SampleDaoImpl(DataSource ds) {
		this.ds = ds;
	}

	public SampleForm fetchProgramDetails(String binNo) {
		SampleForm form = null;
		  try {
			  //Connection c = ds.getConnection();
			  Connection c=DriverManager.getConnection(  
						"jdbc:postgresql://127.0.0.1:5432/test", "postgres", "Admin@123");  
				
		  PreparedStatement stmt = c
				  
		  .prepareStatement(
		  "SELECT binNumber,binName,programCode,programName from program where binNumber=?"
		  );
		  
		  stmt.setString(1, binNo);
		  ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				form = new SampleForm();
				form.setBinName(rs.getString("binName"));
				form.setBinNumber(rs.getString("binNumber"));
				form.setProgramCode(rs.getString("programCode"));
				form.setProgramName(rs.getString("programName"));
			}
		  } catch (Exception e) { e.printStackTrace(); }
		 
			/*
			 * SampleForm form = new SampleForm(); System.out.println("inside daoimpl"); if
			 * (binNo == "400001") { form.setBinName("VisaDebitBin");
			 * form.setBinNumber("400001"); form.setProgramCode("VDP");
			 * form.setProgramName("Visa Debit Program"); }
			 */
		return form;
	}

	public boolean saveBinDetails(SampleForm sampleForm) {
		assertNotNull(sampleForm);
		boolean flag = false;
		try {
		//	Class.forName("oracle.jdbc.driver.PostgresDriver");
			Connection c=DriverManager.getConnection(  
					"jdbc:postgresql://127.0.0.1:5432/test", "postgres", "Admin@123");  
			

			PreparedStatement stmt = c

					.prepareStatement(
							"INSERT INTO program (binNumber, binName, programCode,programName) values (?, ?, ?,?)");

			stmt.setString(1, sampleForm.getBinNumber());

			stmt.setString(2, sampleForm.getBinName());

			stmt.setString(3, sampleForm.getProgramCode());
			stmt.setString(4, sampleForm.getProgramName());

			int count = stmt.executeUpdate();
			System.out.println("count:::" + count);
			if(count > 0) {
				flag = true;
			}
			c.close();
			c.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean updateBinDetails(SampleForm form) {
		boolean flag = false;
		try {

			Connection c = ds.getConnection();

			PreparedStatement stmt = c
					.prepareStatement("UPDATE program SET binName=?, programCode=?,programName=? WHERE binNumber=?");

			stmt.setString(1, form.getBinName());

			stmt.setString(2, form.getProgramCode());

			stmt.setString(3, form.getProgramName());
			stmt.setString(4, form.getBinNumber());
			int count = stmt.executeUpdate();
			if (count > 0) {
				flag = true;
			}
			c.close();

		} catch (SQLException e) {
			e.printStackTrace();

		}
		return flag;
	}

	public boolean deleteDetails(SampleForm form) {
		boolean flag = false;
		try {

			Connection c = ds.getConnection();

			PreparedStatement stmt = c

					.prepareStatement("DELETE FROM program WHERE binNo=?");

			stmt.setString(1, form.getBinNumber());

			int count = stmt.executeUpdate();
			if (count > 0) {
				flag = true;
			}
			c.close();

		} catch (SQLException e) {
			e.printStackTrace();
			// throw new DataAccessException(e);
		}
		return flag;
	}

}
